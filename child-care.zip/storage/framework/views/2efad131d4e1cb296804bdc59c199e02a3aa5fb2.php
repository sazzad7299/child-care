

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="text-center">
        <h1>Assignment</h1>
    </div>
    <div class="row">
        <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4">
            <div class="card m-4">
                <?php if($task->img == "NULL"): ?>
                <embed src="<?php echo e(asset($task->pdf)); ?>"  height= "200">
                <?php else: ?>
                <img class="card-img-top" src="<?php echo e(asset($task->img)); ?>" alt="<?php echo e($task->img); ?>" style="max-height: 200px">
                <?php endif; ?>
                <div class="card-body">
                    <h5 class="card-title"><?php echo e($task->title); ?></h5>
                    <div class="card-text"><?php echo Str::limit($task->inst, 200); ?></div>
                    <a href="<?php echo e(url('assignment/'.$task->id)); ?>" class="btn btn-primary">View</a><a class="item-point"><i class="fas fa-trophy"></i><?php echo e($task->point); ?></a>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
    <div class="text-center">
        <h1>ITEMS</h1>
    </div>
    <div class="row">
        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4">
            <div class="card m-4">
                <img class="card-img-top" src="<?php echo e(asset($item->img)); ?>" alt="<?php echo e($item->img); ?>" style="max-height: 200px">
                <div class="card-body">
                    <h5 class="card-title"><?php echo e($item->title); ?></h5>
                    <div class="card-text"><?php echo Str::limit($item->desc, 200); ?></div>
                   <a class="item-point"><i class="fas fa-trophy"></i><?php echo e($item->point); ?></a>
                    <form action="<?php echo e(route('item_buy')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                         <input  type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>" >
                         <input class="form-control" type="hidden" name="item_id" value="<?php echo e($item->id); ?>">
                         <input class="form-control" type="hidden" name="point" value="<?php echo e($item->point); ?>">
                        <br><br>
                        <a href="<?php echo e(url('item/'.$item->id)); ?>" class="btn btn-primary btn-block">View</a>
                        <input type="submit" onclick="show_alert();" value="Buy" class="btn btn-danger btn-block">
                    </form>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
</div>
<script>
function show_alert() {
  alert("Are You sure want to buy");
}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\child-care-main\themes\frontend\views/home.blade.php ENDPATH**/ ?>