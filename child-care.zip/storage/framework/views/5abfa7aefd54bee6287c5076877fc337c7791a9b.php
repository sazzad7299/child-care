

<?php $__env->startSection('content'); ?>


<div class="max-w-sm w-full lg:max-w-full lg:flex">
    <div class="h-48 lg:h-auto lg:w-48 flex-none bg-cover rounded-t lg:rounded-t-none lg:rounded-l text-center overflow-hidden" style="background-image: url('/img/card-left.jpg')" title="Woman holding a mug">
    </div>
    <div class="border-r border-b border-l border-gray-400 lg:border-l-0 lg:border-t lg:border-gray-400 bg-white rounded-b lg:rounded-b-none lg:rounded-r p-4 flex flex-col justify-between leading-normal">
      <div class="mb-8">
        <?php if(Session::has('success')): ?>
        <div x-data="{ show: true }" x-show="show" class="bg-green-400 border border-green-700 text-white px-4 py-3 rounded relative" role="alert">
          
            <span class="block sm:inline"><?php echo e(Session::get('success')); ?></span>
            <span class="absolute top-0 bottom-0 right-0 px-4 py-3">
              <svg @click="show = false" class="fill-current h-6 w-6 text-red-500" role="button" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><title>Close</title><path d="M14.348 14.849a1.2 1.2 0 0 1-1.697 0L10 11.819l-2.651 3.029a1.2 1.2 0 1 1-1.697-1.697l2.758-3.15-2.759-3.152a1.2 1.2 0 1 1 1.697-1.697L10 8.183l2.651-3.031a1.2 1.2 0 1 1 1.697 1.697l-2.758 3.152 2.758 3.15a1.2 1.2 0 0 1 0 1.698z"/></svg>
            </span>
          </div>
          <?php endif; ?>
          <?php if(Session::has('error')): ?>
          <div x-data="{ show: true }" x-show="show" class="bg-red-100 border border-red-700 text-red-400 px-4 py-3 rounded relative" role="alert">
              <strong class="font-bold">Error!</strong>
              <span class="block sm:inline"><?php echo e(Session::get('error')); ?></span>
              <span class="absolute top-0 bottom-0 right-0 px-4 py-3">
                <svg @click="show = false" class="fill-current h-6 w-6 text-red-500" role="button" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><title>Close</title><path d="M14.348 14.849a1.2 1.2 0 0 1-1.697 0L10 11.819l-2.651 3.029a1.2 1.2 0 1 1-1.697-1.697l2.758-3.15-2.759-3.152a1.2 1.2 0 1 1 1.697-1.697L10 8.183l2.651-3.031a1.2 1.2 0 1 1 1.697 1.697l-2.758 3.152 2.758 3.15a1.2 1.2 0 0 1 0 1.698z"/></svg>
              </span>
            </div>
          <?php endif; ?>
        <p class="text-sm text-gray-600 flex items-center">
            <h1 class=" w-full md:w-1/2 xl:w-1/2 "><strong>Title:</strong> <?php echo e($task->title); ?></h1>
            <?php if($assignment->img == "NULL"): ?>
            <embed src="<?php echo e(asset($assignment->pdf)); ?>" width="100%" height="600px">
            <?php else: ?>
            <img src="<?php echo e(asset($assignment->img)); ?>" class="object-scale-down h-66 w-96">
            <?php endif; ?>

            <a class=" w-full md:w-1/2 xl:w-1/2"><strong>Subject:</strong> <?php echo e($task->topic); ?></a>
            <a class="md:m-8"><i class="fas fa-trophy"></i><?php echo e($task->point); ?></a>
            
        </p>
        <div class="text-gray-900 font-bold text-xl"><?php echo $task->inst; ?></div>
        <p class="text-gray-900 leading-none"><?php echo e($user->name); ?></p>
        <p class="text-gray-600"><?php echo e($assignment->created_at); ?></p>

        <?php if($assignment->img == "NULL"): ?>
        <a href="<?php echo e(asset($assignment->pdf)); ?>" download class="rounded-sm  bg-blue-400 hover:bg-blue-700" >Download</a>
        <?php else: ?>
        <a href="<?php echo e(asset($assignment->img)); ?>" download class="rounded-sm  bg-blue-400 hover:bg-blue-700" >Download</a>
        <?php endif; ?>

        <?php if($assignment->status==1): ?>
        <a href="<?php echo e(route('admin.editStatus',['id'=>$assignment->id])); ?>" class="bg-blue-500 hover:bg-blue-700 text-white font-bold px-4 mx-4 rounded ">Approved</a>
       
        <?php else: ?>
        <a  href="<?php echo e(route('admin.editStatus',['id'=>$assignment->id])); ?>" class="bg-yellow-500 hover:bg-blue-700 text-white font-bold px-4 rounded">Pending</a>
  
        <?php endif; ?>
        <a  href="<?php echo e(route('admin.returnStatus',['id'=>$assignment->id])); ?>" class="bg-red-500 hover:bg-blue-700 text-white font-bold px-4 rounded">Return</a>

        <form action="<?php echo e(route('admin.add_extra_point')); ?>" method="post">
          <?php echo csrf_field(); ?>
           <label for="">Additional point for Behaviour</label><br>
            <input type="number" name="point" placeholder="point for Behaviour" min="1">
           
           <input  type="hidden" name="id" value="<?php echo e($assignment->id); ?>" >
           <input type="submit" value="Add-Point" class="bg-green-500 hover:bg-blue-700 text-white font-bold">
      </form> 
      </div>
    </div>
  </div>
  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\child-care-main\themes\admin\views/tasks/assignment_details.blade.php ENDPATH**/ ?>