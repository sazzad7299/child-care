

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="text-center">
        <h1>Assignment</h1>
    </div>
    <div class="row">
        <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4">
            <div class="card m-4">
                <?php if($task->img == "NULL"): ?>
                <embed src="<?php echo e(asset($task->pdf)); ?>" height= "200">
                <?php else: ?>
                <img class="card-img-top" src="<?php echo e(asset($task->img)); ?>" alt="<?php echo e($task->img); ?>" style="max-height: 200px">
                <?php endif; ?>
                <div class="card-body">
                    <h5 class="card-title"><?php echo e($task->title); ?></h5>
                    <div class="card-text"><?php echo Str::limit($task->inst, 200); ?></div>
                    <a href="<?php echo e(url('assignment/'.$task->id)); ?>" class="btn btn-primary">View</a><a class="item-point"><i class="fas fa-trophy"></i><?php echo e($task->point); ?></a>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\child-care-main\themes\frontend\views/task.blade.php ENDPATH**/ ?>