
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">AlL Orders</h1>
    </div>

    <?php if(empty($purchases)): ?>
    <h1>Not found any order</h1>
    <?php else: ?>
    <table id="dataTable" class="table table-bordered">
        <thead>
          <tr class="text-center" style="background:rgb(35, 35, 245)">
            <th scope="col" class="text-white">#.</th>
            <th scope="col" class="text-white">Name</th>
            <th scope="col" class="text-white">item Name</th>
            <th scope="col" class="text-white">Item Image</th>
            <th scope="col" class="text-white">Point</th>
            <th scope="col" class="text-white">Status</th>
            
          </tr>
        </thead>
        <tbody>
            <?php ($i=1); ?>
          <?php $__currentLoopData = $purchases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php (
            $user=\DB::table('users')->where('id',$purchase->user_id)->first()
          ); ?>
          <?php ($item= \DB::table('items')->where('id',$purchase->item_id)->first()); ?>
            <tr class="text-center">
                <td class="border px-4 py-2"><?php echo e($i++); ?></td>
                <td class="border px-4 py-2"><?php echo e($user->name); ?></td>
                <td class="border px-4 py-2"><?php echo e($item->title); ?></td>
                <td class="border px-4 py-2"><img src="<?php echo e(asset($item->img)); ?>" height="60" width="60" alt=""></td>
                <td class="border px-4 py-2"><?php echo e($item->point); ?></td>
                <?php if($purchase->status==1): ?>
                <td class="border px-4 py-2">Approved</td>
                <?php else: ?>
                <td class="border px-4 py-2">Pending</td>
                <?php endif; ?>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>

      <?php endif; ?>
</div>   

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\child-care-main\themes\frontend\views/order/view_purchase.blade.php ENDPATH**/ ?>