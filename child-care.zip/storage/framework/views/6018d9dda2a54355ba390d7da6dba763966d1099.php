

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="text-center">
        <h1 class="text-success"><?php echo e(Session::get('success')); ?></h1>
       
    </div>
    <div class="row">
        <div class="col-md-8 col-sm-12">
            <h1><em class="fas fa-tasks" style="color: orange; background:rgb(163, 81, 136);padding:8px; border:1px; border-radius:20px"></em> <?php echo e($item->title); ?></h1>
            
            <div class="card m-4">
                <img class="card-img-top" src="<?php echo e(asset($item->img)); ?>" height="400" alt="<?php echo e($item->img); ?>">
                                
                <div class="card-body">
                
                    <a class="item-point"><i class="fas fa-trophy"></i><?php echo e($item->point); ?></a>
                    <div class="card-text"><?php echo $item->desc; ?></div>
                    <a href="#" class="btn btn-danger btn-block">Buy</a> 

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\child-care-main\themes\frontend\views/item/single.blade.php ENDPATH**/ ?>