<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(mix('js/app.js', 'themes/frontend')); ?>" defer></script>
    <script src="<?php echo e(asset('themes/frontend/js/all.min.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(mix('css/app.css', 'themes/frontend')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('themes/frontend/css/all.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('themes/frontend/css/custom.css')); ?>" rel="stylesheet">
    
</head>
<body>
    <div id="app">
        <nav class="bg-white shadow-sm navbar navbar-expand-md navbar-light">
            <div class="container">
                
                <?php if(auth()->guard()->guest()): ?>
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                <?php echo e(config('app.name')); ?>

                </a>
                <?php else: ?>
                <h2>Hi!<?php echo e(Auth::user()->name); ?></h2>
                <?php endif; ?>
                
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="mr-auto navbar-nav">

                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="ml-auto navbar-nav">
                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                            <?php if(Route::has('login')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                                </li>
                            <?php endif; ?>

                            <?php if(Route::has('register')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                                </li>
                            <?php endif; ?>
                        <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('home')); ?>">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('show_assignment')); ?>">Assignment</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('showItem')); ?>">Item's</a>
                        </li>
                        <li class="nav-item">
                            <form action="<?php echo e(route('showOrders')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                 <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>" >
                                <input type="submit" value="Orders's" class="nav-link">
                            </form> 
                        </li>
            
                                            
                        <li class="nav-item">
                            <a class="nav-link"> <i class="fas fa-trophy"></i>
                      
                        <?php ( $currentDay = Carbon\Carbon::tomorrow()->format('l')=="Tuesday"); ?>                 
                            <?php if($currentDay): ?>
                                <?php ($sum=\DB::table('std_assignments')->where('user_id', Auth::user()->id)
                                ->where('status','1')->sum('point')); ?> 
                                <?php (\DB::table('std_assignments')->where('user_id', Auth::user()->id)
                                ->where('status','1')->update(['point_sum'=>$sum])); ?>
                            <?php endif; ?>

                            <?php ($TotalSum=\DB::table('std_assignments')->where('user_id', Auth::user()->id)
                            ->where('status','1')->max('point_sum')); ?>
                            <?php if($TotalSum): ?>
                               <?php echo e($TotalSum); ?>

                            <?php else: ?>
                                 0
                            <?php endif; ?>
                        
                            </a>
                        </li>
                        <li class="nav-item" >
                            <a class="nav-link" href="<?php echo e(route('logout')); ?>"
                                onclick="event.preventDefault();
                                                document.getElementById('logout-form').submit();" style="color:red; font-size:18px">
                                <em class="fas fa-sign-out-alt" ></em><?php echo e(__('Logout')); ?>

                            </a>
                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                <?php echo csrf_field(); ?>
                            </form>
                        </li>   
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>

        <main class="py-4">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\child-care-main\themes\frontend\views/layouts/app.blade.php ENDPATH**/ ?>